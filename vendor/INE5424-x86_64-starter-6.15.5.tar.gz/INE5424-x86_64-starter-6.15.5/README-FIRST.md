# INE5424 x86_64 Minimal Linux Starter 6.15.5

This bundle contains a precompiled, validated x86_64 Linux environment for Practical Class 1.

## Included

- `bzImage`: Linux 6.15.5 with `PREEMPT_RT`.
- `kernel.config`: exact kernel build configuration.
- `initramfs.cpio`: minimal static BusyBox userspace.
- `rootfs/`: editable source tree for the initramfs.
- `hello.c` and `hello`: static starter application.
- `run-vm.sh`: boots one VM with a unique MAC and the class multicast network.
- `install-app.sh`: verifies and installs a static x86_64 executable as `/student/app`.
- `repack-initramfs.sh`: rebuilds `initramfs.cpio` from `rootfs/`.
- `BUILDINFO.txt` and `SHA256SUMS`: provenance and integrity information.

The raw-Ethernet communication solution is intentionally not included. Students must design and implement that part.

## First boot

```bash
tar -xzf INE5424-x86_64-starter-6.15.5.tar.gz
cd INE5424-x86_64-starter-6.15.5
sha256sum -c SHA256SUMS
./run-vm.sh 1
```

Expected output includes:

```text
Linux ... PREEMPT_RT ... x86_64
Hello from the precompiled INE5424 x86_64 VM!
SO2_VM_ID=1
```

Inside the VM:

```sh
uname -a
ip -br link
poweroff -f
```

## Install a student application

The executable must be x86_64 and statically linked:

```bash
gcc -static -O2 -Wall -Wextra -o my_app my_app.c
file my_app
./install-app.sh ./my_app
./run-vm.sh 1
```

`/init` starts `/student/app` automatically and leaves an interactive shell available.

## VM network contract

Every `run-vm.sh ID` instance uses:

- multicast endpoint `230.0.0.1:1234`;
- MAC `02:00:00:00:00:ID`;
- `virtio-net-pci` attached as `eth0`;
- no required guest IP configuration.

Use distinct IDs from 1 to 254. Read the course QEMU networking material before implementing communication.


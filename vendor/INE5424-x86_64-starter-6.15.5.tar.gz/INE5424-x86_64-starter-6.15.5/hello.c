#include <stdio.h>
#include <stdlib.h>
#include <sys/utsname.h>

int main(void)
{
    struct utsname system_info;
    const char *vm_id = getenv("SO2_VM_ID");

    puts("Hello from the precompiled INE5424 x86_64 VM!");
    printf("SO2_VM_ID=%s\n", vm_id ? vm_id : "unset");

    if (uname(&system_info) == 0) {
        printf("Kernel=%s %s, machine=%s\n",
               system_info.sysname,
               system_info.release,
               system_info.machine);
    }

    return 0;
}

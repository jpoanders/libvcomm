#!/bin/bash
set -euo pipefail

APP_INPUT="${1:?usage: ./install-app.sh <static-x86_64-executable>}"
APP="$(readlink -f -- "$APP_INPUT")"
if [[ ! -f "$APP" || ! -x "$APP" ]]; then
    echo "$APP_INPUT is not an executable file" >&2
    exit 1
fi

cd "$(dirname "$0")"

if ! file "$APP" | grep -q 'x86-64'; then
    echo "$APP is not an x86-64 executable" >&2
    exit 1
fi

if ! file "$APP" | grep -q 'statically linked'; then
    echo "$APP is not statically linked; rebuild it with -static" >&2
    exit 1
fi

install -D -m 0755 "$APP" rootfs/student/app
./repack-initramfs.sh

echo "Installed $APP as /student/app. It will execute during /init."

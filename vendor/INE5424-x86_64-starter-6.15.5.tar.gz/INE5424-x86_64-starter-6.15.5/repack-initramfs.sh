#!/bin/bash
set -euo pipefail

cd "$(dirname "$0")"

if [[ ! -x rootfs/init ]]; then
    echo "rootfs/init is missing or not executable" >&2
    exit 1
fi

(
  cd rootfs
  find . -print0 | cpio --null -o --format=newc
) > initramfs.cpio

echo "Created $(pwd)/initramfs.cpio"
du -h initramfs.cpio

#!/bin/bash
set -euo pipefail

cd "$(dirname "$0")"

VM_ID="${1:?usage: ./run-vm.sh <id 1-254>}"
MCAST="${SO2_MCAST:-230.0.0.1:1234}"

if (( VM_ID < 1 || VM_ID > 254 )); then
    echo "VM id must be between 1 and 254" >&2
    exit 1
fi

MAC=$(printf '02:00:00:00:00:%02x' "$VM_ID")

exec qemu-system-x86_64 \
  -machine q35 \
  -m 128M \
  -smp 1 \
  -nographic \
  -kernel bzImage \
  -initrd initramfs.cpio \
  -append "console=ttyS0 root=/dev/ram rdinit=/init so2.vm_id=$VM_ID" \
  -netdev socket,id=net0,mcast="$MCAST" \
  -device virtio-net-pci,netdev=net0,mac="$MAC"
